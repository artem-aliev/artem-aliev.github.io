/*
 * Created on 30.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package events;

/**
 * @author aaaliev
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface Message {
	public static final int START = 0;
	public static final int QUIT = 1;
	public static final int DATA = 2;
	public static final int RESULTS = 3;
	
	int getType();

}
