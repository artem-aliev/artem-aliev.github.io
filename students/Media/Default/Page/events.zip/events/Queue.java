/*
 * Created on 30.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package events;

/**
 * @author aaaliev
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Queue {
    Object data[];
    int size = 1000;
    int head =0;
    int tail =0;
	/**
	 * 
	 */
	public Queue() {
		data = new Object[size];
	}

	public void enqueue(Object o) {
		data[tail] = o;
		tail++;
		if(tail == size) {
			tail = 0;
		}
		if(tail == head) {
			throw new RuntimeException("QUEUE is overflow");
		}
	}
	
	public Object dequeue () {
		if (head == tail) { 
			throw new RuntimeException("QUEUE is Empty");
		}
		Object res = data[head];
		head++;
		if(head == size) {
			head = 0;
		}
		return res;
	}
	
	public boolean isEmpty() {
		return head == tail;
	}

}
