/*
 * Created on 30.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package events;

/**
 * @author aaaliev
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ResultHandler implements Handler {
    Matrix data;
    Dispatcher dispatcher;
    int resultCounter =0;
	/**
	 * 
	 */
	public ResultHandler(Matrix m, Dispatcher d) {
		data = m;
		dispatcher = d;
		
	}

	/* (non-Javadoc)
	 * @see events.Handler#handle(events.Message)
	 */
	public void handle(Message m) {
		if(!(m instanceof VectorMessage) || m.getType() != Message.RESULTS) {
			return;
		}
		resultCounter++;
		if(resultCounter == data.rowCount()){
			dispatcher.send(new QuitMessage());
		}
	}

}
