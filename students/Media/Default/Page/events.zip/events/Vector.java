/*
 * Created on 30.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package events;

/**
 * @author aaaliev
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface Vector {
	int size();
	double get(int i);
	void set(int i, double value);

}
