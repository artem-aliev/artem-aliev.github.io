/*
 * Created on 30.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package events;

/**
 * @author aaaliev
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class VectorGenerartor implements Generator {

	private Matrix matrix;
	private Dispatcher dispatchet;
	int countColumns = 0;

	/**
	 * 
	 */
	public VectorGenerartor(Matrix m, Dispatcher d) {
		matrix =m;
		dispatchet = d;
		
	}

	/* (non-Javadoc)
	 * @see events.Generator#generate()
	 */
	public Message generate() {
		if (countColumns == matrix.columnCount()) {
			return new QuitMessage();
		}
		return new VectorMessage(matrix.getColumn(countColumns++), Message.DATA);
	}

}
