/*
 * Created on 30.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package events;

/**
 * @author aaaliev
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class VectorMulHandler implements Handler {

	private Vector data;
	private Vector result;
	int currentResultElement = 0;
	private Dispatcher dispatcher;

	public VectorMulHandler (Vector data, Vector result, Dispatcher d) {
		this.data = data;
		this.result = result;
		dispatcher = d;
	}
	
	public void handle(Message m) {
		if(!(m instanceof VectorMessage) || m.getType() != Message.DATA) {
			return;
		}
		double res = mul(data, ((VectorMessage)m).getData());
		result.set(currentResultElement, res);
		currentResultElement++;
		if(currentResultElement == result.size()) {
			// send results
			dispatcher.send(new VectorMessage(result, Message.RESULTS));
			// reset result counter
			currentResultElement=0;
		}
		
	}

	/**
	 * @param data2
	 * @param data3
	 * @return
	 */
	private double mul(Vector a, Vector b) {
		double sum = 0;
		for(int i = 0; i < a.size(); i++) {
			sum+=a.get(i)*b.get(i);
			
		}
		return sum;
	}



}
