package mvc;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
/*
 * Action facrory
 */
public class ActionKit {
	public static InsertAtcion createInsertAtcion(Dictionary struct, TreeView source) {
		return new InsertAtcion(struct, source);
	}
	public static FindAtcion createFindAtcion(Dictionary struct, TreeView source) {
		return new FindAtcion(struct, source);
	}
}

class InsertAtcion extends AbstractAction {
	Dictionary struct;
	TreeView view;
	

	InsertAtcion(Dictionary struct, TreeView source){
		super("insert");
		this.struct = struct;
		this.view = source;
	}
	
	public void actionPerformed(ActionEvent e) {
		try { 
			int key = Integer.parseInt((view.field.getText()));
			struct.insert (key, view.field.getText());
			System.out.println("insert: " + key);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
}

class FindAtcion extends AbstractAction {
	Dictionary struct;
	TreeView view;
	

	FindAtcion(Dictionary struct, TreeView source){
		super("find");
		this.struct = struct;
		this.view = source;
	}
	
	public void actionPerformed(ActionEvent e) {
		try { 
			int key = Integer.parseInt((view.field.getText()));
			if(struct.find (key) != null)
				System.out.println("find: " + key);		
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}