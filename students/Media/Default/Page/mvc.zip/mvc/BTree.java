package mvc;
import java.util.Vector;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;


/**
 * This class provide btree implementation. It support only insert and search, 
 * see Dictionary interface.
 * It extends DefaultTreeModel to support TreeModel compatible with JTree view
 *   
 */
public class BTree extends DefaultTreeModel implements Dictionary {
	public static int MIN_DEGREE = 2;
	public BTree () {
		super(new Node (MIN_DEGREE));
	}
	
	// Dictionary interface implementation
	public void insert (int key, Object value){
		insert(new Entry (key, value));
	}
	
	public Object find(int key) {
		Entry e = search(key, (Node)root);
		return e==null?null:e.getValue();
		
	}

	// BTREE implementation
	private void splitChild (Node parent, int parentIndex, Node child) {
		Node nNode = new Node(MIN_DEGREE);
		for (int i = 0; i < MIN_DEGREE-1; i++) {
			nNode.addEntry(child.removeEntry(MIN_DEGREE/*+i**/));
		}

		if(!child.isLeaf()) {
			for (int i = 0; i < MIN_DEGREE; i++) {
				Node c =  (Node)child.getChildAt (MIN_DEGREE/*+i**/);
				//child.remove(c);
				removeNodeFromParent(c);
				//nNode.add(c);
				insertNodeInto(c, nNode, nNode.getChildCount());
			}
		}
		//parent.insert (nNode, parentIndex + 1);
		// "Write nodes": next line will also notify view
		insertNodeInto(nNode, parent, parentIndex + 1);
		parent.insertEntry(parentIndex, child.removeEntry(MIN_DEGREE-1));
	}


	private void insert(Entry e) {
		Node r = (Node)getRoot();
		if(r.getSize() == MIN_DEGREE * 2-1) {
			// create new root and split old one
			Node s = new Node (MIN_DEGREE);
			setRoot(s);
			s.add(r);
			splitChild(s,0,r);
		}
		insertNonFull((Node)getRoot(), e);
	}

	private void insertNonFull (Node node, Entry e) {
		int eKey = e.getKey();
		int i = node.getSize()-1;
		if (node.isLeaf()) {
			for (; i >= 0 
					 && eKey < node.getEntry(i).getKey(); i--);
			node.insertEntry(i+1,e);
			//  "write node": notify view
			nodeChanged(node);
		} else {
			for (; i >= 0 
					 && eKey < node.getEntry(i).getKey(); i--);
			i++;
			Node child = (Node)node.getChildAt(i);
			// "read child"
			if (child.getSize() == 2*MIN_DEGREE-1 ) {
				splitChild(node, i, child);
				if(eKey > node.getEntry(i).getKey()) {
					i++;
				}
			}
			insertNonFull ((Node)node.getChildAt(i), e);
		}
	}
			

    /** search */

    public Entry search(int key, Node node) {
        int l = 0;
		int i = node.getSize()-1;
        for (; i >= 0 
                 && key < node.getEntry(i).getKey(); i--);
        if(i >=0 && node.getEntry(i).getKey() == key) {
            return node.getEntry(i);
        }

        if(node.isLeaf()) {
            return null;
        } else {
            // read i+1 child
            return search (key, (Node)node.getChildAt(i+1));
        }
    }
}

/**
 * Node extends DefaultMutableTreeNode with Entry storage 
 */

class Node extends DefaultMutableTreeNode{
	Vector  entries = new Vector();
	Node children [] = null;
	int degree;
	boolean leaf = true;
	int count = 0;
	public Node (int degree) {
		super();
		this.degree = degree;
		userObject = entries;
	}

	public void addEntry (Entry e) {
		entries.add(e);
	}

	public void insertEntry (int i, Entry e) {
		entries.add(i, e);
	}

	public boolean removeEntry (Entry e) {
		return entries.remove(e);
	}

	public Entry removeEntry (int i) {
		return (Entry)entries.remove(i);
	}

	public Entry getEntry (int i) {
		return (Entry) entries.elementAt(i);
	}

	public int getSize() {
		return entries.size();
	}
}

/**
 * Class to store key-value pair  
 */
class Entry {
	int key;
	Object value;

	public Entry (int key, Object value) {
		this.key = key;
		this.value = value;
	}

	public int getKey() {
		return key;
	}

	public Object getValue() {
		return value;
	}
	
	public String toString() {
		return "" + key;
	}
						   
}
