/*
 * Created on 06.04.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package mvc;

import java.awt.BorderLayout;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;

/**
 * @author aaaliev
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TreeView {
    DefaultTreeModel document;
    final JTree treeView;
    final JTextField field;
    
    public TreeView(DefaultTreeModel tree) {
    	this.document = tree;
		JFrame f = new JFrame ("B-tree");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		treeView = new JTree (tree);
		field = new JTextField (10);
		Action insertAction = ActionKit.createInsertAtcion((Dictionary)tree, this);
		Action findAction = ActionKit.createFindAtcion((Dictionary)tree, this);

		field.setAction (insertAction);
        JButton insertButton = new JButton(insertAction);
        JButton findButton = new JButton(findAction);

	    JPanel opPanel = new JPanel();
        opPanel.add(field);
        opPanel.add(insertButton);
        opPanel.add(findButton);
        
		f.getContentPane().add(opPanel,  BorderLayout.SOUTH);
		f.getContentPane().add(treeView);
		f.setSize(400, 400);
		f.setVisible(true);
    	
    }
    
	public static void main (String args[]) {
		BTree t = new BTree();
		new TreeView(t);

	}
}

