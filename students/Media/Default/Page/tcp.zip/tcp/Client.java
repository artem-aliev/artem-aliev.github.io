import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;


public class Client {
	
	Socket s;
	BufferedReader in;
	BufferedWriter out;
	
	public Client(InetAddress host, int port) throws UnknownHostException, IOException {
        s = new Socket (host, port);
        in = new BufferedReader(new InputStreamReader(s.getInputStream()));
        out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
	}

	public void send(String message) throws IOException {
		out.write(message);
		out.newLine();
		out.flush();
	}

	public String recv() throws IOException {
		return in.readLine();
	}

	public boolean hasAnswers() throws IOException {
		return in.ready();
	}
	public static void main(String args[]) {
		if(args.length  < 2) {
 			System.out.println("Usage: Host port");
            System.exit(-1);
        }
		try {
			InetAddress host = InetAddress.getByName(args[0]);
			int port = Integer.parseInt(args[1]);
            Client c = new Client (host, port);
            BufferedReader std = new BufferedReader(new InputStreamReader(System.in));
 
             while(true) {
                    if(std.ready()) {
                    	String message = std.readLine();
                        c.send(message);
                    }
                    
                	while (c.hasAnswers()) {
                		String ans = c.recv();
                		if(ans == null) {
                			System.out.println("Conection closed by peer ...");
                			System.exit(0);
                		}
                		System.out.println(ans);
                		System.out.flush();
                	}
                }
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        }
}
