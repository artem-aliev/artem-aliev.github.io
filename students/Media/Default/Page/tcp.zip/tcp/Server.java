import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

/*
 * Created on 16.03.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author aaaliev
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public abstract class Server {
	
	ServerSocket s;
	
	public Server (int port) throws IOException {
		 s = new ServerSocket(port);
 	}

	private void send(BufferedWriter out, String message) throws IOException {
		out.write(message);
		out.newLine();
		out.flush();
	}

	private String recv(BufferedReader in) throws IOException {
		return in.readLine();
	}

	public void run() throws IOException {
		while(true) {
			Socket cl = s.accept();
			BufferedReader in = new BufferedReader(new InputStreamReader(cl.getInputStream()));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(cl.getOutputStream()));
			send(out, processMessage(recv(in)));
			cl.close();
		}
		 
	}
	
	/**
	 * Devewloper should override
	 * 
	 * @param message recieved from clent
	 * @return answer to send
	 * @throws IOException
	 */
	public abstract String processMessage(String message);

	public static void main(String[] args) {
		if(args.length  < 1) {
 			System.out.println("Usage: port");
            System.exit(-1);
        }

		try {
			int port = Integer.parseInt(args[0]);			 			
			Server serv = new Server(port) {
				public String processMessage(String message) {
					System.out.println(message);
					return "Not " + message;
				}		
			};
			serv.run();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
